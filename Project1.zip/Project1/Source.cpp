#include "Header.h"

void judge(int i_e, int n_s, int t_f, int p_j) {
	char result[5];
	result[4] = 0;

	if (i_e < 0) result[0] = 'I';
	else result[0] = 'E';
	if (n_s < 0) result[1] = 'N';
	else result[1] = 'S';
	if (t_f < 0) result[2] = 'T';
	else result[2] = 'F';
	if (p_j < 0) result[3] = 'P';
	else result[3] = 'J';
	printf("%s", result);
}

int convertAnswerToScore(int answer) {
	int score = 0;
	if (answer == 1) score = -2;
	else if (answer == 2) score = -1;
	else if (answer == 3) score = 0;
	else if (answer == 4) score = 1;
	else if (answer == 5) score = 2;
	else score = 0;

	return score;
}

int getAnswer(const char* prompt) {
	int answer;
	printf(prompt);
	printf("�ſ� �׷���(5 ~ 1)�׷����ʴ� : ");
	scanf("%d", &answer);
	fseek(stdin, 0, SEEK_END);

	return answer;
}