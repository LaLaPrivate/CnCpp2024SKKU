#ifndef __HEADER_H__
#define __HEADER_H__

#define _CRT_SECURE_NO_WARNINGS

#define QUESTION_SIZE 3

#include <cstdio>
#include <cstdlib>

void judge(int i_e, int n_s, int t_f, int p_j);
int convertAnswerToScore(int answer);
int getAnswer(const char* prompt);

#endif
